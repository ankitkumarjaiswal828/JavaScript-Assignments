const arr = [
  {
    pro_id: "1",
    pro_name: "mobile",
    pro_price: "12000",
    pro_des: "This sumsung mobile",
    pro_img: "a.png",
  },
  {
    pro_id: "2",
    pro_name: "TV",
    pro_price: "19000",
    pro_des: "This sumsung TV",
    pro_img: "b.png",
  },
  {
    pro_id: "3",
    pro_name: "car",
    pro_price: "150000",
    pro_des: "This is fortuner car",
    pro_img: "c.png",
  },
  {
    pro_id: "4",
    pro_name: "Bike",
    pro_price: "90000",
    pro_des: "This  is Hero Bike",
    pro_img: "e.png",
  },
  {
    pro_id: "5",
    pro_name: "ByeCycle",
    pro_price: "10000",
    pro_des: "This is Hero electric Byecycle",
    pro_img: "f.png",
  },
];

const tableBoody = document.querySelector("#data-table tbody");

arr.forEach((item) => {
  const data = document.createElement("tr");

  data.innerHTML = `
    <td>${item.pro_id}</td>
    <td>${item.pro_name}</td>
    <td>${item.pro_price}</td>
    <td>${item.pro_img}</td>
    <td>${item.pro_des}</td>
    `;
  tableBoody.appendChild(data);
});
