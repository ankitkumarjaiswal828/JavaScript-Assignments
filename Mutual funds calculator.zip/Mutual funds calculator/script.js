function handleSIP(event){
    event.preventDefault();
    let amt = document.getElementById("amt").value;
    let duration = document.getElementById("duration").value;
    let rate = document.getElementById("rate").value;
    rate  = rate/12/100;

     let futureValue = 0;
     futureValue = amt*(Math.pow(1+rate,duration)-1)/rate;
     let amttotalInvestment = amt*duration;
     console.log(amttotalInvestment)
    console.log(futureValue)
    document.getElementById('resultamt').innerHTML = "Rs. " +amttotalInvestment;
    document.getElementById('futureValue').innerHTML = "Rs. " +Math.round(futureValue>0?futureValue:0);
}


function handleLumpsum(event){
     event.preventDefault();
     let lpsamt = document.getElementById("lamt").value;
     let lpsduration = document.getElementById("lduration").value;
     let lpsrate = document.getElementById("lrate").value;
     
     console.log(lpsamt);
     console.log(lpsduration);
     console.log(lpsrate);

     const futureValue =lpsamt *(1 + lpsrate / 100) ** lpsduration;
     document.getElementById("resultlpsamt").innerHTML ="Rs. " + lpsamt;
     document.getElementById("lpsfutureValue").innerHTML ="Rs. " + Math.round(futureValue > 0 ? futureValue : 0);
}

