var countries = ["India", "USA", "Canada", "UK"];

var states = {
  India: ["Karnataka", "Maharashtra", "Tamil Nadu"],
  USA: ["California", "New York", "Texas"],
  Canada: ["Ontario", "Quebec", "British Columbia"],
  UK: ["England", "Scotland", "Wales"],
};

var districts = {
  Karnataka: ["Bangalore", "Mysore", "Hubli"],
  Maharashtra: ["Mumbai", "Pune", "Nagpur"],
  "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai"],
  California: ["Los Angeles", "San Francisco", "San Diego"],
  "New York": ["New York City", "Buffalo", "Rochester"],
  Texas: ["Houston", "Dallas", "Austin"],
  Ontario: ["Toronto", "Ottawa", "Mississauga"],
  Quebec: ["Montreal", "Quebec City", "Laval"],
  "British Columbia": ["Vancouver", "Victoria", "Surrey"],
  England: ["London", "Manchester", "Birmingham"],
  Scotland: ["Edinburgh", "Glasgow", "Aberdeen"],
  Wales: ["Cardiff", "Swansea", "Newport"],
};

var cities = {
  Bangalore: ["Electronic City", "Whitefield", "JP Nagar"],
  Mumbai: ["Andheri", "Dadar", "Colaba"],
  Chennai: ["Anna Nagar", "T Nagar", "Mylapore"],
  "Los Angeles": ["Downtown", "Hollywood", "Santa Monica"],
  "San Francisco": ["Financial District", "Chinatown", "Fisherman's Wharf"],
  "San Diego": ["Downtown", "Gaslamp Quarter", "La Jolla"],
};

let cutrydrop = document.getElementById('country');
let stedrop = document.getElementById('state');
let dstctdrop = document.getElementById('district');
let ctydrop = document.getElementById('city')

function updateStates(){
    let chosecuntry = cutrydrop.value;
    let show_state = states[chosecuntry];
    stedrop.innerHTML = '';

    show_state.forEach(states=>{

        const opt = document.createElement('option');
        opt.value = states;
        opt.textContent = states;
        stedrop.appendChild(opt)
    })
    updateDistricts();
    stedrop.addEventListener("change", updateDistricts);
}



function updateDistricts() {
  let choseste = stedrop.value;
  let show_district = districts[choseste];
  dstctdrop.innerHTML = "";
  console.log(show_district)

  show_district.forEach((distric) => {
    const opt = document.createElement("option");
    opt.value = distric;
    opt.textContent = distric;
    dstctdrop.appendChild(opt);
  });
  updateCities();
  dstctdrop.addEventListener("change", updateCities);
}


function updateCities(){
    let choosedistrict = dstctdrop.value;
    let show_cities = cities[choosedistrict];
    ctydrop.innerHTML ="";

    show_cities.forEach((citi)=>{
         const opt = document.createElement("option");
         opt.value = citi;
         opt.textContent = citi;
         ctydrop.appendChild(opt);
         console.log(citi)
    })
}

updateStates();
cutrydrop.addEventListener("change", updateStates);

