function add(){
    var num1 = document.getElementById("ist").value;
    var num2 = document.getElementById("sec").value;
    let val = parseInt(num1) + parseInt(num2);
    console.log(val)
  return document.getElementById("res").value = val;
}

function sub() {
  var num1 = document.getElementById("ist").value;
  var num2 = document.getElementById("sec").value;
  let val = parseInt(num1) - parseInt(num2);
  console.log(val);
  return (document.getElementById("res").value = val);
}

function mul() {
  var num1 = document.getElementById("ist").value;
  var num2 = document.getElementById("sec").value;
  let val = parseInt(num1) * parseInt(num2);
  console.log(val);
  return (document.getElementById("res").value = val);
}

function div() {
  var num1 = document.getElementById("ist").value;
  var num2 = document.getElementById("sec").value;
  let val = parseInt(num1) / parseInt(num2);
  console.log(val);
  return (document.getElementById("res").value = val);
}
