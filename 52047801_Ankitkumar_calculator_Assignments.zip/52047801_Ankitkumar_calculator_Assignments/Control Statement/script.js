function Age_Check() {
  let age = document.getElementById("age").value;
  if (age >= 18) {
    document.getElementById("result").innerHTML =
      "Your are Eligible for Voting";
    document.getElementById("result").style.color = "green";
  } else {
    document.getElementById("result").innerHTML =
      "Your are not Eligible for Voting";
    document.getElementById("result").style.color = "red";
  }
}

function Grade_Check() {
  let grade = document.getElementById("grade").value;
  switch (true) {
    case grade >= 0 && grade < 33:
      document.getElementById("result2").innerHTML = "Your Grade F(Fail)";
      document.getElementById("result2").style.color = "red";
      break;

    case grade >= 33 && grade <= 50:
      document.getElementById("result2").innerHTML = "Your Grade A(Average)";
      document.getElementById("result2").style.color = "orange";
      break;

    case grade > 50 && grade <= 80:
      document.getElementById("result2").innerHTML = "Your Grade G(Good)";
      document.getElementById("result2").style.color = "yellowgreen";
      break;

    case grade > 80 && grade <= 100:
      document.getElementById("result2").innerHTML = "Your Grade E(Excellent)";
      document.getElementById("result2").style.color = "green";
      break;

    default:
      return (document.getElementById("result2").innerHTML =
        "Please enter valid Percentage!!");
  }
}

function gen_triangle() {
  let num = document.getElementById("row").value;

  if (num === 0 || num === 1) return 1;
  for (var i = num - 1; i >= 1; i--) {
    num = num * i; 
  }
 return document.getElementById("result3").innerHTML = num ;
}

function gen_series(){
    let limit = document.getElementById("series").value;
    let a = 0,b = 1;
    let result=[]

    if(limit >= 1) {
      result.push(a);
    }
    if(limit >= 2) {
      result.push(b);
    }

    let count = 2;
    while(count < limit) {
      let next = a + b;
      result.push(next);
      a = b;
      b = next;
      count++;
    }

    return document.getElementById("result4").innerHTML = result ;
}