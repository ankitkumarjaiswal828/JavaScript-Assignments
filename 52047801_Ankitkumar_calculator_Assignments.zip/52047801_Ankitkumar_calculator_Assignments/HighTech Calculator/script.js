function display(value){
     document.getElementById("data").value += value;

}

function result(){
    let expression = document.getElementById("data").value;
    try {
      let result = eval(expression);
      document.getElementById("data").value = result;
    } catch (error) {
      document.getElementById("data").value = "Error";
    }
}
// The eval() function in JavaScript can be used to evaluate mathematical expressions written as 
// strings. For example, if you have the string '5+2+6-3*4' , you can use eval() to evaluate it
// like this: javascript. let expression = '5+2+6-3*4'; let result = eval(expression); console.
// eval(2*4)
// 8
// eval(2-4)
// -2
// eval(2+4)
// 6

function clearScreen(){
    document.getElementById("data").value= '';
}