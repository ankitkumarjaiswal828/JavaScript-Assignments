function updateClock() {
  const samya = new Date();
  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];
  const dayNames = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
  ];

  const hours = String(samya.getHours()).padStart(2, "0");
  const amPm = hours >= 12 ? "PM" : "AM";
  const hour = hours % 12 || 12;

  const minutes = String(samya.getMinutes()).padStart(2, "0");
  const seconds = String(samya.getSeconds()).padStart(2, "0");
  document.getElementById("time").textContent = `${hour}:${minutes}:${seconds} ${amPm}`;

  const day = dayNames[samya.getDay()];
  const date = samya.getDate()
  const month = monthNames[samya.getMonth()];
  const year = String(samya.getFullYear())
  document.getElementById("date").textContent = `${date}-${day}-${month}-${year}`;

}

setInterval(updateClock, 1000);

